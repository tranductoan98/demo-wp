jQuery(document).ready(function(){

	jQuery('#view_kp_logs').click(function(){
		jQuery('#kp-logs-wrapper').toggleClass('open');
	});
});