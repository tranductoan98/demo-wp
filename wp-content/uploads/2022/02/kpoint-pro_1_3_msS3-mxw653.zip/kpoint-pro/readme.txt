=== KPOINT ===
Contributors: dangngocbinh
Requires at least: 4.8
Tested up to: 5.4
Requires PHP: 5.3
Stable tag: 1.0
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

KPOINT helps your customers record reward points and use them to make purchases or discounts.
You will have a loyal customer base thanks to KPOINT

KPOINT giúp khách hàng của bạn ghi nhận điểm thưởng và sử dụng chúng để mua hàng hoặc giảm giá.
Bạn sẽ có một lượng khách hàng trung thành nhờ vào KPOINT

== Description ==

KPOINT giúp bạn dễ dàng quan lý điểm thưởng của khách hàng trên Woocommerce. 

- Tặng điểm khi đăng ký tài khoản
- Tặng điểm khi mua hàng 
- Sử dụng điểm để thanh toán
- Nạp điểm bằng tiền 

= Sử dụng cực kỳ đơn giản =

- Tuỳ biến tên loại điểm thưởng: Xu, Xèng, Big Xu, Ngân Lượng ...
- Cổng thanh toán bằng điểm dư đang có 


== Frequently Asked Questions ==

= Tôi cần custom tính năng phải làm sao? =

Xin hãy gởi tính năng yêu cầu trong mục cài đặt của plugin . Tính năng đó sẽ được chúng tôi đưa vào trong bản tiếp theo hoặc sẽ custom riêng cho bạn theo yêu cầu.




== Installation ==

Sau khi cài đặt bạn có thể vào Setting -> K-Point 
- Bạn đặt tên điểm thưởng thành loại tiền tệ riêng của 
bạn
- Bạn tạo một số mệnh giá để khách có thể mua điểm bằng tiền 

== Screenshots ==

1. Hiện số dư tài khoản và lịch sử giao 
2. Khách có thể dùng số điểm tài khoản để mua hàng
3. Cấu hình tặng điêm khi tạo tài khoản hoặc mua hàng
4. Khách có thể nạp điểm bằng tiền thật
5. Quản lý điểm thưởng của tường user.

== Contributors & Developers ==


== Changelog ==
= 1.1 =
Thêm: Admin chỉnh sửa điểm user
Cập nhật: lịch sử giao dịch
= 1.0 =

**K-POINT**
* first release
